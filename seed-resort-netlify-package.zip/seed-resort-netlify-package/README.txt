SEED Resort Concierge — Netlify package

Upload the CONTENTS of the site/ folder to Netlify using Deploy manually.

Before sharing the deployed URL:
1. Edit site/config.js.
2. Set apiBaseUrl to the public HTTPS URL of the separately hosted API.
3. Set clerkPublishableKey to your Clerk publishable key.
4. Upload the updated site/ folder again.

See NETLIFY_DEPLOYMENT.md and api-server-handoff.md for details.
Never put Clerk secret keys, OpenAI keys, database URLs, or session secrets in site/config.js.
